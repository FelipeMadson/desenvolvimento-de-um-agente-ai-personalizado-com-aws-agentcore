# Desenvolvimento de um Agente AI Personalizado com AWS AgentCore

[![CI Status](https://github.com/FelipeMadson/desenvolvimento-de-um-agente-ai-personalizado-com-aws-agentcore/actions/workflows/ci.yml/badge.svg)](https://github.com/FelipeMadson/desenvolvimento-de-um-agente-ai-personalizado-com-aws-agentcore/actions)
[![Latest Release](https://img.shields.io/github/v/release/FelipeMadson/desenvolvimento-de-um-agente-ai-personalizado-com-aws-agentcore?color=145e4d&logo=github)](https://github.com/FelipeMadson/desenvolvimento-de-um-agente-ai-personalizado-com-aws-agentcore/releases)
[![Conventional Commits](https://img.shields.io/badge/Conventional%20Commits-1.0.0-yellow.svg)](https://conventionalcommits.org)
[![SemVer 2.0.0](https://img.shields.io/badge/semver-2.0.0-blue.svg)](https://semver.org)

[![CI Status](https://github.com/FelipeMadson/desenvolvimento-de-um-agente-ai-personalizado-com-aws-agentcore/actions/workflows/ci.yml/badge.svg)](https://github.com/FelipeMadson/desenvolvimento-de-um-agente-ai-personalizado-com-aws-agentcore/actions)
[![Latest Release](https://img.shields.io/github/v/release/FelipeMadson/desenvolvimento-de-um-agente-ai-personalizado-com-aws-agentcore?color=145e4d&logo=github)](https://github.com/FelipeMadson/desenvolvimento-de-um-agente-ai-personalizado-com-aws-agentcore/releases)
[![Conventional Commits](https://img.shields.io/badge/Conventional%20Commits-1.0.0-yellow.svg)](https://conventionalcommits.org)
[![SemVer 2.0.0](https://img.shields.io/badge/semver-2.0.0-blue.svg)](https://semver.org)

> **Microsserviço Enterprise de IA com FastAPI, Vector RAG e Agentes ReAct**
> Autor: **Felipe Madison** · GitHub: [@FelipeMadson](https://github.com/FelipeMadson)

---

## 🎯 Proposta de Valor
undefined

- **FastAPI 0.115+ & Pydantic v2:** Validação rigorosa de esquemas de entrada e saída.
- **In-Memory Vector RAG:** Indexação vetorial determinística com busca semântica por Cosseno.
- **ReAct Autonomous Agent:** Orquestrador de raciocínio cíclico (*Thought $\to$ Action $\to$ Observation*).
- **Zero-Dependency Core Testability:** Testes rodam instantaneamente com `python -m unittest`.

---

## 🏗️ Diagrama do Agente ReAct

```mermaid
sequenceDiagram
    autonumber
    actor User as Usuário / Cliente
    participant API as FastAPI Gateway
    participant Agent as ReAct Agent Engine
    participant RAG as Vector Index RAG
    participant Tools as Tool Registry

    User->>API: POST /api/v1/agent/run {"objective": "..."}
    API->>Agent: Executar objetivo
    loop ReAct Thought Loop
        Agent->>Agent: Gerar Thought (Raciocínio)
        Agent->>Tools: Executar Action selecionada
        Tools-->>Agent: Observation (Resultado)
    end
    Agent-->>API: Resposta Final Sintetizada
    API-->>User: JSON {"status": "completed", "trajectory": [...]}
```

---

## 🚀 Execução e Testes

### Executar Testes Automatizados (Zero-Deps)
```bash
python -m unittest discover -s tests -p "test_*.py"
```

### Iniciar o Microsserviço com Uvicorn
```bash
pip install -r requirements.txt
uvicorn app.main:app --reload --port 8000
```

### Documentação Interativa Swagger / OpenAPI
Acesse: `http://localhost:8000/docs`

---

## 📄 Licença
Distribuído sob a licença MIT. Criado por **Felipe Madison**.

---

## 🖥️ Demonstração em Terminal Vetorial (Execução & Benchmarks)

<p align="center">
  <img src="docs/assets/terminal-demo.svg" alt="Terminal Demo - Desenvolvimento De Um Agente Ai Personalizado Com Aws Agentcore" width="840" />
</p>

---

## 📦 Polyglot Client SDKs (TypeScript & Python)

SDKs tipados com zero dependências externas em `sdk/`:

```typescript
import { desenvolvimentodeumagenteaipersonalizadocomawsagentcoreClient } from "./sdk/ts/client.ts";
const client = new desenvolvimentodeumagenteaipersonalizadocomawsagentcoreClient({ baseUrl: "http://127.0.0.1:3000" });
const health = await client.checkHealth();
console.log("Health:", health.status);
```
